from django.db import models
# Create your models here.

class login_A(models.Model):
    admin_name=models.CharField(max_length=30)
    admin_pass=models.CharField(max_length=30)   
    def __str__(self):
        return f"{self.admin_name} / {self.admin_pass}"
class login_HO(models.Model):
    houseowner_name=models.CharField(max_length=30)
    houseowner_pass=models.CharField(max_length=30)   
    def __str__(self):
        return f"{self.houseowner_name} / {self.houseowner_pass}"
class houseowner_PROFILE(models.Model):
    image= models.FileField(upload_to='static/semfive_app',null=True,blank=True)
    name=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    mobile_number=models.CharField(max_length=30,null=True,blank=True)
    email_id=models.CharField(max_length=30,null=True,blank=True)
    gender=models.CharField(max_length=30,null=True,blank=True)
    date=models.CharField(max_length=30,null=True,blank=True)
    address_houseno=models.CharField(max_length=200,null=True,blank=True)
    address_city=models.CharField(max_length=200,null=True,blank=True)
    address_pin=models.CharField(max_length=200,null=True,blank=True)
    address_state=models.CharField(max_length=200,null=True,blank=True)   
    def __str__(self):
        return f"{self.name} / {self.password} / {self.gender} / {self.mobile_number}"
class login_U(models.Model):
    user_name=models.CharField(max_length=30)
    user_pass=models.CharField(max_length=30)   
    def __str__(self):
        return f"{self.user_name} / {self.user_pass}"
class user_PROFILE(models.Model):
    image= models.FileField(upload_to='static/semfive_app',null=True,blank=True)
    name=models.CharField(max_length=30)
    password=models.CharField(max_length=30)
    mobile_number=models.CharField(max_length=30,null=True,blank=True)
    email_id=models.CharField(max_length=30,null=True,blank=True)
    gender=models.CharField(max_length=30,null=True,blank=True)
    date=models.CharField(max_length=30,null=True,blank=True)
    address_houseno=models.CharField(max_length=200,null=True,blank=True)
    address_city=models.CharField(max_length=200,null=True,blank=True)
    address_pin=models.CharField(max_length=200,null=True,blank=True)
    address_state=models.CharField(max_length=200,null=True,blank=True)   
    def __str__(self):
        return f"{self.name} / {self.password} / {self.gender} / {self.mobile_number}"
    
    
    
class city_HOUSE(models.Model):
    city_name=models.CharField(max_length=30)
    city_image= models.FileField(upload_to='static/semfive_app', null=True,blank=True)
    house1_id=models.CharField(max_length=30,blank=True)   
    house2_id=models.CharField(max_length=30,blank=True)
    house3_id=models.CharField(max_length=30,blank=True)
    house4_id=models.CharField(max_length=30,blank=True)
    house5_id=models.CharField(max_length=30,blank=True)
    house6_id=models.CharField(max_length=30,blank=True)   
    house7_id=models.CharField(max_length=30,blank=True)
    house8_id=models.CharField(max_length=30,blank=True)
    house9_id=models.CharField(max_length=30,blank=True)
    house10_id=models.CharField(max_length=30,blank=True)
    house11_id=models.CharField(max_length=30,blank=True)   
    house12_id=models.CharField(max_length=30,blank=True)
    house13_id=models.CharField(max_length=30,blank=True)
    house14_id=models.CharField(max_length=30,blank=True)
    house15_id=models.CharField(max_length=30,blank=True)
    def __str__(self):
        return f"{self.city_name}"
class house_DETAILS(models.Model):
    house_owner_id=models.CharField(max_length=30,null=True,blank=True)
    house_user_id=models.CharField(max_length=30,null=True,blank=True)
    house_owner_name=models.CharField(max_length=30,null=True)
    house_id=models.CharField(max_length=30,null=True,blank=True)
    house_name=models.CharField(max_length=30)
    house_type=models.CharField(max_length=30)
    house_price=models.CharField(max_length=30)
    house_status=models.CharField(max_length=30)
    house_address_houseno=models.CharField(max_length=200,null=True,blank=True)
    house_address_city=models.CharField(max_length=200,null=True,blank=True)
    house_address_pin=models.CharField(max_length=200,null=True,blank=True)
    house_address_state=models.CharField(max_length=200,null=True,blank=True)   
    house_image= models.FileField(upload_to='static/semfive_app', null=True,blank=True)
    def __str__(self):
        return f"{self.house_name} / {self.house_price} / {self.house_owner_name}"
    
class user_DETAILS(models.Model):
    house_id=models.CharField(max_length=30,null=True,blank=True)
    first_name=models.CharField(max_length=30,null=True,blank=True)
    last_name=models.CharField(max_length=30,null=True,blank=True)
    age=models.EmailField(max_length=30,null=True,blank=True)
    gender=models.CharField(max_length=30,null=True,blank=True)
    mobile=models.CharField(max_length=30,null=True,blank=True)
    email=models.EmailField(max_length=50,null=True,blank=True)
    def __str__(self):
        return f"{self.house_id} / {self.first_name} / {self.last_name} / {self.age} / {self.gender} / {self.mobile} / {self.email}"



