from django.urls import path
from . import views
urlpatterns = [
    path("",views.first_page,name="first"),
    
    path("HOUSEOWNER_LOGIN",views.houseowner_login,name="house_owner"),
    path("HOUSEOWNER_SIGNUP",views.houseowner_signup,name="house_owner_register"),
    path("HOUSEOWNER_TASKS",views.houseowner_tasks,name="house_owner_tasks"),
    path("HOUSEOWNER_2.1/HOUSEOWNER_TASKS",views.houseowner_tasks,name=""),
    path("HOUSEOWNER_1",views.houseowner_task1,name="house_owner_1"),
    path("HOUSEOWNER_2",views.houseowner_task2,name="house_owner_2"),
    path("HOUSEOWNER_2.1/<int:id>",views.houseowner_task2_1,name="house_owner_2.1"),
    path("HOUSEOWNER_3",views.houseowner_task3,name="house_owner_3"),
    
    path("USER_LOGIN",views.user_login,name="user"),
    path("USER_SIGNUP",views.user_signup,name="user_register"),
    path("USER_TASKS",views.usertasks,name="user_tasks"), 
    path("User_2.1/USER_TASKS",views.usertasks,name=""), 
    path("USER_1",views.user_task1,name="user_1"),
    path("USER_1.1",views.user_task1_1,name="user_1.1"),
    path("<int:id>",views.user_task1_1ID,name="user_1.1ID"),  
    path("User_1.2/<int:id>",views.user_task1_2,name="user_1.2"),
    path("User1_3",views.user_task1_3,name="user_1.3"),
    path("USER_2",views.user_task2,name="user_2"),
    path("User_2.1/<int:id>",views.user_task2_1,name="user_2.1"),
    path("USER_3",views.user_task3,name="user_3"),
] 
