from django.apps import AppConfig


class SemfiveAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'semfive_app'
