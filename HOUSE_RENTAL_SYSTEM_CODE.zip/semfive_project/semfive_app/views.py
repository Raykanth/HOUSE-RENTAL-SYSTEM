from django.shortcuts import render
from django.http.response import HttpResponseRedirect
from .models import *
from .forms import *

def first_page(request):
    return render(request,"semfive_app/1.html")

global houseowner_id,houseowner_password
global houseuser_id,houseuser_password
global c_name,h_name,i2

def houseowner_login(request):
    global houseowner_id,houseowner_password
    data_HOL=login_HO.objects.all()
    if request.method == "POST":
        houseowner_id = request.POST['h_owner_name']
        houseowner_password = request.POST['h_owner_pass']
        n=int(data_HOL.count())
        for a in range(n):
            if houseowner_id==data_HOL[a].houseowner_name:
                p=a
                break
        if houseowner_password==data_HOL[p].houseowner_pass:
            return HttpResponseRedirect("HOUSEOWNER_TASKS")
    return render(request,"semfive_app/houseowner_login.html")

def houseowner_signup(request):
    global houseowner_id,houseowner_password
    if request.method == "POST":
        houseowner_id=request.POST['houseowner_name']
        houseowner_password=request.POST['houseowner_pass']
        b=login_HO(
            houseowner_name=houseowner_id,
            houseowner_pass=houseowner_password)
        b.save()
        a=houseowner_PROFILE(
            name=houseowner_id,
            password=houseowner_password,
            gender=" ",date=" ",
            mobile_number=" ",email_id=" ",
            address_houseno=" ",address_city=" ",
            address_pin=" ",address_state=" ",
            image="static/semfive_app/A1.jpg")
        a.save()
        return HttpResponseRedirect("HOUSEOWNER_TASKS")
    return render(request,"semfive_app/houseowner_signup.html")

def houseowner_tasks(request):
    return render(request,"semfive_app/houseowner_tasks.html")

def houseowner_task1(request):
    s=houseowner_id
    if request.method == "POST":
        A=house_DETAILS(
            house_owner_id=s,
            house_owner_name=request.POST['ownername'],
            house_name=request.POST['housename'],
            house_id=request.POST['houseid'],
            house_type=request.POST['housetype'],
            house_price=request.POST['houseprice'],
            house_status=request.POST['housestatus'],
            house_address_houseno=request.POST['houseno'],
            house_address_city=request.POST['addresscity'],
            house_address_pin=request.POST['addresspin'],
            house_address_state=request.POST['addressstate'],
        )
        A.save()
        AB=city_HOUSE.objects.get(city_name=request.POST['addresscity'])
        if AB.house2_id=="":
            AB.house2_id=request.POST['houseid']
            AB.save(update_fields=["house2_id"])
            AB.save()
        elif AB.house3_id=="":
            AB.house3_id=request.POST['houseid']
            AB.save(update_fields=["house3_id"])
            AB.save()
        elif AB.house4_id=="":
            AB.house4_id=request.POST['houseid']
            AB.save(update_fields=["house4_id"])
            AB.save()
        elif AB.house5_id=="":
            AB.house5_id=request.POST['houseid']
            AB.save(update_fields=["house5_id"])
            AB.save()
        elif AB.house6_id=="":
            AB.house6_id=request.POST['houseid']
            AB.save(update_fields=["house6_id"])
            AB.save()
        elif AB.house7_id=="":
            AB.house7_id=request.POST['houseid']
            AB.save(update_fields=["house7_id"])
            AB.save()
        elif AB.house8_id=="":
            AB.house8_id=request.POST['houseid']
            AB.save(update_fields=["house8_id"])
            AB.save()
        elif AB.house9_id=="":
            AB.house9_id=request.POST['houseid']
            AB.save(update_fields=["house9_id"])
            AB.save()
        elif AB.house10_id=="":
            AB.house10_id=request.POST['houseid']
            AB.save(update_fields=["house10_id"])
            AB.save()
        elif AB.house11_id=="":
            AB.house11_id=request.POST['houseid']
            AB.save(update_fields=["house11_id"])
            AB.save()
        elif AB.house12_id=="":
            AB.house12_id=request.POST['houseid']
            AB.save(update_fields=["house12_id"])
            AB.save()
        elif AB.house13_id=="":
            AB.house13_id=request.POST['houseid']
            AB.save(update_fields=["house13_id"])
            AB.save()
        elif AB.house14_id=="":
            AB.house14_id=request.POST['houseid']
            AB.save(update_fields=["house14_id"])
            AB.save()
        elif AB.house15_id=="":
            AB.house15_id=request.POST['houseid']
            AB.save(update_fields=["house15_id"])
            AB.save()
        return HttpResponseRedirect("HOUSEOWNER_TASKS")
    form=add_HOUSE()
    return render(request,"semfive_app/houseowner_1.html",{
        'form1': form
    })
    
def houseowner_task2(request):
    data_HD=house_DETAILS.objects.all()
    return render(request,"semfive_app/houseowner_2.html",{
        "m":data_HD,"H_ID":houseowner_id
    })
    
def houseowner_task2_1(request,id):
    data_HD_S=house_DETAILS.objects.get(pk=id)
    i=data_HD_S.house_image
    i1=str(i)
    i2=i1.replace("static/","")
    if request.method == "POST":
        h = request.POST['ABCD']
        h1 = request.POST['BCDE']
        h2=str(h)
        h3=str(h1)
        data_HD_S.house_name=h2
        data_HD_S.house_price=h3
        data_HD_S.save(update_fields=["house_name","house_price"])
        data_HD_S.save()
        
        return HttpResponseRedirect("HOUSEOWNER_TASKS")
    return render(request,"semfive_app/houseowner_2.1.html",{
        "HD_S":data_HD_S,"ZS":i2
    })
    
def houseowner_task3(request):
    a=houseowner_id
    a1=houseowner_password
    AB=houseowner_PROFILE.objects.get(name=a)
    ABC=login_HO.objects.get(houseowner_name=a)
    if request.method == "POST":
        AB.name=request.POST['u_name']
        ABC.user_name=request.POST['u_name']
        AB.password=request.POST['u_pass']
        ABC.user_pass=request.POST['u_pass']
        AB.date=request.POST['d_o_b']
        AB.gender=request.POST['gen']
        AB.mobile_number=request.POST['m_no']
        AB.email_id=request.POST['e_id']
        AB.address_houseno=request.POST['add_hno']
        AB.address_city=request.POST['add_city']
        AB.address_pin=request.POST['add_pin']
        AB.address_state=request.POST['add_state']

        AB.save(update_fields=["image","name","password","date","gender",
                               "mobile_number","email_id",
                               "address_houseno","address_city","address_pin","address_state"])
        ABC.save(update_fields=["houseowner_name","houseowner_pass"])
        AB.save()  
        ABC.save()
        return HttpResponseRedirect("HOUSEOWNER_TASKS")
    return render(request,"semfive_app/houseowner_3.html",{
        "a":a,"a1":a1,"A":AB
    })
    
def user_login(request):
    global houseuser_id,houseuser_password
    data_UL=login_U.objects.all()
    if request.method == "POST":
        houseuser_id = request.POST['user_name']
        houseuser_password = request.POST['user_pass']   
        n=int(data_UL.count())
        for a in range(n):
            if houseuser_id==data_UL[a].user_name:
                if houseuser_password==data_UL[a].user_pass:
                    return HttpResponseRedirect("USER_TASKS")
        
    return render(request,"semfive_app/user_login.html")

def user_signup(request):
    if request.method == "POST":
        houseuser_id=request.POST['user_name']
        houseuser_password=request.POST['user_pass']
        b=login_U(
            user_name=houseuser_id,
            user_pass=houseuser_password)
        b.save()
        a=user_PROFILE(
            name=houseuser_id,
            password=houseuser_password,
            gender=" ",date=" ",
            mobile_number=" ",email_id=" ",
            address_houseno=" ",address_city=" ",
            address_pin=" ",address_state=" ",
            image="static/semfive_app/A1.jpg")
        a.save()
        return HttpResponseRedirect("USER_TASKS")
    return render(request,"semfive_app/user_signup.html")

def usertasks(request):
    global c_name
    data_CH=city_HOUSE.objects.all()
    if request.method == "POST":
        c_name = request.POST['myCountry']
        return HttpResponseRedirect("USER_1.1")
    return render(request,"semfive_app/user_tasks.html",{
        "m":data_CH
    })

def user_task1(request):
    data_CH=city_HOUSE.objects.all()
    data_HD=house_DETAILS.objects.all()
    return render(request,"semfive_app/user_1.html",{
        "m":data_CH,"n":data_HD
    })

def user_task1_1(request):
    AB=city_HOUSE.objects.get(city_name=c_name)
    data_HD=house_DETAILS.objects.all()
    return render(request,"semfive_app/user_1.1.html",{
        "n":AB,"m": data_HD
    })
      
def user_task1_1ID(request,id):
    data_CH_S=city_HOUSE.objects.get(pk=id)
    data_HD=house_DETAILS.objects.all()
    return render(request,"semfive_app/user_1.1.html",{
    "n":data_CH_S,"m": data_HD
    })
    
def user_task1_2(request,id):
    global h_name,i2
    data_HD=house_DETAILS.objects.all()
    data_HD_S=house_DETAILS.objects.get(pk=id)
    h_name=data_HD_S.house_name
    n=int(data_HD.count())
    for a in range(n):
        if data_HD[a].house_name==h_name:
            p=a
            break
    i=data_HD[p].house_image
    i1=str(i)
    i2=i1.replace('static/','')
    status=data_HD[p].house_status
    F="FILLED"
    return render(request,"semfive_app/user_1.2.html",{
        "m":data_HD_S,"S":status,"F":F,"qq":i2
    })
      
def user_task1_3(request) :
    a=h_name
    a0=houseuser_id
    a1=i2
    if request.method == "POST":
        AB=house_DETAILS.objects.get(house_name=a)
        AB.house_user_id=a0
        AB.house_status="FILLED"
        AB.save(update_fields=["house_status","house_user_id"])
        AB.save()  
        p=AB.house_id
        p1=str(p)
        b=user_DETAILS(
            house_id=p1,
            first_name=request.POST['first_name'],
            last_name=request.POST['last_name'],
            age=request.POST['age'],
            gender=request.POST['gender'],
            mobile=request.POST['mobile_number'],
            email=request.POST['email_id'],
        )
        b.save()
        return HttpResponseRedirect("USER_TASKS")
    return render(request,"semfive_app/user_1.3.html",{
        "i":a1
    })
            
def user_task2(request):
    data_HD=house_DETAILS.objects.all()
    return render(request,"semfive_app/user_2.html",{
        "m":data_HD,"H_UD":houseuser_id
    })             

def user_task2_1(request,id):
    data_HD=house_DETAILS.objects.all()
    data_HD_S=house_DETAILS.objects.get(pk=id)
    h_name25=data_HD_S.house_name
    n=int(data_HD.count())
    for a in range(n):
        if data_HD[a].house_name==h_name25:
            p=a
            break
    i=data_HD[p].house_image
    i1=str(i)
    i2=i1.replace('static/','')
    if request.method == "POST":
        AB=house_DETAILS.objects.get(house_name=h_name25)
        l=AB.house_id
        ABC=user_DETAILS.objects.get(house_id=l)
        ABC.delete()
        AB.house_user_id=""
        AB.house_status="EMPTY"
        AB.save(update_fields=["house_status","house_user_id"])
        AB.save()
        return HttpResponseRedirect("USER_TASKS")
    return render(request,"semfive_app/user_2.1.html",{
        "m":data_HD_S,"qq":i2
    })   

def user_task3(request):
    a=houseuser_id
    a1=houseuser_password
    AB=user_PROFILE.objects.get(name=a)
    ABC=login_U.objects.get(user_name=a)
    if request.method == "POST":
        AB.name=request.POST['u_name']
        ABC.user_name=request.POST['u_name']
        AB.password=request.POST['u_pass']
        ABC.user_pass=request.POST['u_pass']
        AB.date=request.POST['d_o_b']
        AB.gender=request.POST['gen']
        AB.mobile_number=request.POST['m_no']
        AB.email_id=request.POST['e_id']
        AB.address_houseno=request.POST['add_hno']
        AB.address_city=request.POST['add_city']
        AB.address_pin=request.POST['add_pin']
        AB.address_state=request.POST['add_state']

        AB.save(update_fields=["image","name","password","date","gender",
                               "mobile_number","email_id",
                               "address_houseno","address_city","address_pin","address_state"])
        ABC.save(update_fields=["user_name","user_pass"])
        AB.save()  
        ABC.save()
        return HttpResponseRedirect("USER_TASKS")
    return render(request,"semfive_app/user_3.html",{
        "a":a,"a1":a1,"A":AB
    })