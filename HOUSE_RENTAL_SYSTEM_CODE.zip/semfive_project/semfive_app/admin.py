from django.contrib import admin
from .models import *
# Register your models here.

admin.site.register(login_HO),
admin.site.register(login_U),
admin.site.register(house_DETAILS),
admin.site.register(city_HOUSE),
admin.site.register(user_DETAILS),
admin.site.register(user_PROFILE),
admin.site.register(houseowner_PROFILE)
