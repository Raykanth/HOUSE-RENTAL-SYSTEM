from django import forms
from .models import *

class user_REGISTRATION(forms.Form):
    username=forms.CharField()
    password=forms.CharField()
    repassword=forms.CharField()
    
class houseowner_REGISTRATION(forms.Form):
    username=forms.CharField()
    password=forms.CharField()
    repassword=forms.CharField()
    
class add_HOUSE(forms.Form):
    house_image= forms.ImageField()
